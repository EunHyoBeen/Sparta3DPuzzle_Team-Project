﻿namespace Puzzle
{
    public class PuzzleEventBus
    {
        
    }
}