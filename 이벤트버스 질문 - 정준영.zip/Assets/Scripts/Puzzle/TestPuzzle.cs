﻿
    using UnityEngine;

    public class TestPuzzle : PuzzleControllerBase
    {
        protected override void OnPuzzleClear()
        {
            Debug.Log("Test Puzzle 기믹 온");
        }
    }
